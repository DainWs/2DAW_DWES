<?php
/**
 * This only redirect to home.php
 */
header("Location: public/Home.php");
exit;